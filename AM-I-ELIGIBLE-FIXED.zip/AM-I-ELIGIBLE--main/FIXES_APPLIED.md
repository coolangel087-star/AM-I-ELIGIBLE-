# Eligibility engine fixes applied

These changes address the two major problems in the original project:

1. **Profiles/results were being reused.** The app previously seeded a fake graduate profile and stored the profile/results in `sessionStorage`. The checker now starts with neutral/blank user data and keeps the current profile/results in memory only.
2. **Eligibility logic was too broad.** The engine now validates the actual submitted profile, uses cycle-specific DOB windows, avoids inventing universal category mark relaxations, checks stored degree/experience requirements, and no longer labels an official attempt cap as “attempts remaining” when attempts-used data is not available.
3. **Cycle-specific DOB windows are not extrapolated.** For NDA/CDS-style exact DOB windows, future opportunities are left as dependent on the next official notification rather than incorrectly returning zero.
4. **Empty marks are no longer silently replaced with 70/75/80.** The form now sends missing marks as undefined so the backend can mark criteria for verification instead of treating fake defaults as real student marks.

## Important remaining data-model work

Some opportunities in the seeded demo database combine multiple routes/posts under one record (for example RRB NTPC and NDA wings). Those should eventually be split into separate opportunity records so post/wing-specific eligibility can be calculated accurately.

The project was syntax-checked for `server/eligibilityEngine.ts` and `shared/types.ts` with TypeScript. Full project build could not be run in this environment because the npm dependencies were not installed.
