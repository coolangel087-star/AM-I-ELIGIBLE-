import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, EligibilityResponse } from '../types.ts';

interface EligibilityContextType {
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  results: EligibilityResponse | null;
  setResults: (res: EligibilityResponse | null) => void;
  resetProfile: () => void;
}

const DEFAULT_PROFILE: UserProfile = {
  // Deliberately blank/neutral. Never ship fake student data as a user's profile.
  dob: '',
  gender: 'any',
  citizenship: 'indian',
  state: '',
  domicileState: '',
  category: 'General',
  isPwBD: false,
  currentEducation: 'class12',
  class12Status: 'passed',
  subjects: {
    maths: false,
    physics: false,
    chemistry: false,
    biology: false,
    english: false,
  },
};

const EligibilityContext = createContext<EligibilityContextType>({
  profile: DEFAULT_PROFILE,
  setProfile: () => {},
  results: null,
  setResults: () => {},
  resetProfile: () => {},
});

export const EligibilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Keep personal eligibility data in memory only. This prevents one person using the
  // same browser/session from inheriting another person's DOB, marks or results.
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [results, setResultsState] = useState<EligibilityResponse | null>(null);

  const setResults = (res: EligibilityResponse | null) => {
    setResultsState(res);
  };

  const resetProfile = () => {
    setProfile(DEFAULT_PROFILE);
    setResults(null);
  };

  return (
    <EligibilityContext.Provider value={{ profile, setProfile, results, setResults, resetProfile }}>
      {children}
    </EligibilityContext.Provider>
  );
};

export const useEligibility = () => useContext(EligibilityContext);
